#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

/*********Additional Libraries*********/
#include <math.h>
#include <stdint.h>
#include <ctype.h>
/*************************************/

/* The RGB values of a pixel. */
struct Pixel
{
    uint16_t red;
    uint16_t green;
    uint16_t blue;
};

/* The Node to store the comments as linked list */
struct Node
{
    char *comment;
    struct Node *next;
};

/* An image loaded from a PPM file. */
struct PPM
{
    char format[3];
    struct Node *comments;
    int width;
    int height;
    uint16_t max;
    struct Pixel *pixels;
};

/*********************************************************/
/* Defining Global Constants */
#define _PPM_ struct PPM
#define _Pixel_ struct Pixel

/* Pre Defining Auxilary functions */
void exception(char *messaage);
void comments_retriever(FILE *f, struct Node *head);
void garbage_collector(_PPM_ *img);
unsigned int countBits(unsigned int num);
void encryptBit(struct Pixel *pixel, int bit);

/*********************************************************/

/*********************************************************
 * Reads an image from an open PPM file.
 * Returns a new struct PPM, or NULL if the image cannot be read.
 **********************************************************/
struct PPM *getPPM(FILE *f)
{
    fprintf(stderr, "============ Image Memory Allocations =========== \n");

    // Allocating memory for the image
    _PPM_ *img = malloc(sizeof(_PPM_));
    if (img == NULL)
        exception("Memory Allocation Failed");
    fprintf(stderr, "Image Memory: %ld Bytes\n", sizeof(_PPM_));

    // Ensure that the file is not empty
    if (f == NULL)
    {
        fprintf(stderr, "File could not be opened.\n");
        return NULL;
    }

    // Reading the format of the image
    int l = fscanf(f, "%s", img->format);
    if (l == EOF)
        exception("The file is empty");

    // Checking if the format is P3
    if (strcmp(img->format, "P3") != 0)
        exception("The format of the image is not P3");

    // Reading the comments
    struct Node *head = malloc(sizeof(struct Node)); // Temperory variable to store the head of the linked list
    if (head == NULL)
        exception("Memory Allocation Failed");

    head->next = NULL;
    head->comment = NULL;
    comments_retriever(f, head); // Function to read the comments
    img->comments = head; // Assigning the head of the linked list to the image

    if (head->comment == NULL)
    {
        img->comments = NULL;
        free(head);
    }

    // Reading the width and height of the image
    img->height = 0;
    img->width = 0;
    l = fscanf(f, "%d %d", &img->width, &img->height);

    // Checking if the file is empty
    if (l == EOF)
        exception("The file is empty");

    // Checking if the width and height are defined
    if (!(img->height && img->width))
        exception("Height or Width of the image is not defined");

    // Reading the max value of the image
    img->max = 0;
    l = fscanf(f, "%hu", &img->max);

    // Checking if the file is empty
    if (l == EOF)
        exception("The file is empty");

    // Checking if max value is defined and is greater than 0
    if (img->max <= 0)
        exception("Max value of the image is not defined or is less than 0");

    // Allocating memory for the pixels pointers
    unsigned int Total_Pixels = img->height * img->width;
    img->pixels = malloc(sizeof(_Pixel_) * Total_Pixels);
    if (img->pixels == NULL)
        exception("Memory Allocation Failed");

    fprintf(stderr, "Pixel array Memory: %ld Bytes\n", sizeof(_Pixel_) * Total_Pixels);

    // Reading the pixels
    for (int i = 0; i < Total_Pixels; i++)
    {  
        l = fscanf(f, "%hu %hu %hu", &img->pixels[i].red, &img->pixels[i].green, &img->pixels[i].blue);
        if (l == EOF)
            exception("The file is empty");
    }
    fprintf(stderr, "=================================================== \n");

    return img;
}

/**********************************************************
 *   Write img to stdout in PPM format.
 **********************************************************/
void showPPM(const struct PPM *img)
{
    // Printing the format of the image
    printf("%s\n", img->format);

    // Printing the comments
    struct Node *temp = img->comments;
    while (temp != NULL && temp->comment != NULL)
    {
        printf("%s", temp->comment);
        temp = temp->next;
    }

    // Printing the width and height of the image
    printf("%d %d\n", img->width, img->height);

    // Printing the max value of the image
    printf("%hu\n", img->max);

    // Printing the pixels into matrix form (4 pixels per line)
    for (int i = 0; i < img->height * img->width; i++)
    {
        printf("%hu %hu %hu ", img->pixels[i].red, img->pixels[i].green, img->pixels[i].blue);

        if (i % 4 == 0)
            printf("\n");
    }
}

/**********************************************************
 * Opens and reads a PPM file, returning a pointer to a new struct PPM.
 * On error, prints an error message and returns NULL.
 **********************************************************/
struct PPM *readPPM(const char *filename)
{
    /* Open the file for reading */
    FILE *f = fopen(filename, "r");
    if (f == NULL)
    {
        fprintf(stderr, "File %s could not be opened.\n", filename);
        return NULL;
    }

    /* Load the image using getPPM */
    struct PPM *img = getPPM(f);

    /* Close the file */
    fclose(f);

    if (img == NULL)
    {
        fprintf(stderr, "File %s could not be read.\n", filename);
        return NULL;
    }

    return img;
}

/**********************************************************
 * Encode the string text into the red channel of image img.
 * Returns a new struct PPM, or NULL on error.
 **********************************************************/
struct PPM *encode(const char *text, const struct PPM *img)
{
    // Checking if the text is empty
    if (text == NULL)
    {
        exception("The text is empty");
    }

    // Checking if the image is empty
    if (img == NULL)
    {
        exception("The image is empty");
    }

    // Creating a new image
    struct PPM *new_img = malloc(sizeof(_PPM_));

    // copying the data from the old image to the new image
    strcpy(new_img->format, img->format);
    new_img->comments = img->comments;
    new_img->height = img->height;
    new_img->width = img->width;
    new_img->max = img->max;

    // Allocating memory for the pixels pointers
    unsigned int Total_Pixels = new_img->height * new_img->width;

    // Copying the pixels from the old image to the new image
    new_img->pixels = malloc(sizeof(_Pixel_) * Total_Pixels);
    for(int i = 0; i < Total_Pixels; i++)
    {
        new_img->pixels[i].red = img->pixels[i].red;
        new_img->pixels[i].green = img->pixels[i].green;
        new_img->pixels[i].blue = img->pixels[i].blue;
    }

    // Data regrading the image
    int length = strlen(text);
    int TotalReservedPixelBits = countBits(Total_Pixels);
    fprintf(stderr, "Total Reserved Pixels: %d\n", TotalReservedPixelBits);

    // Generating a random position for the intial position of the message
    // The intial position can be anywhere after the Reserved Pixels
    // Reserved Pixels = TotalPixelBits
    int intial_pos = (rand() + new_img->height + new_img->width) % Total_Pixels; // Random Position
    if (intial_pos <= TotalReservedPixelBits)
    {
        intial_pos += TotalReservedPixelBits; // Wrap Around the Reserved Pixels
    }

    // Write the Intial Position into the image
    for (int i = 0; i < TotalReservedPixelBits; i++)
    {
        new_img->pixels[i].red &= ~1; // Clearing the last bit
        new_img->pixels[i].red |= (intial_pos >> (TotalReservedPixelBits - 1 - i)) & 1; // Setting the bit
    }

    // AIM: to Spread the message evenly across the image
    // Calculating Distance between each bit
    int distance = Total_Pixels / (length * 8 + TotalReservedPixelBits);

    // Encoding the message in the red bit of the image, using srand and rand
    for (int i = 0; i < strlen(text); i++)
    {
        char c = text[i];
        // Each character is encoded in 8 bits (Extended ASCII)
        for (int j = 0; j < 8; j++)
        { 
            int bit = (c >> (7 - j)) & 1; // Extracting the Message Char bit 
            int position = (intial_pos + (i * 8 + j) * distance) % Total_Pixels; // Wrap Arround

            if (position < intial_pos)
            {
                position += TotalReservedPixelBits; // Wrap Around the Reserved Pixels
            }

            // Encrypting the bit
            encryptBit(&new_img->pixels[position], bit);
        }
    }

    // Calculating the MSE between the old image and the new image
    double MSE = 0;
    for (int i = 0; i < Total_Pixels; i++)
    {
        MSE += pow((new_img->pixels[i].red - img->pixels[i].red), 2); 
    }
    MSE = MSE / Total_Pixels;
    fprintf(stderr, "Mean Square Error (MSE): %f \n", MSE);

    // Calculating the PSNR between the old image and the new image
    
    double PSNR = 10 * log10(pow(new_img->max, 2) / MSE);
    fprintf(stderr, "Peak Signal to Noise Ratio (PSNR): %3.2f dB\n", PSNR);

    if (PSNR < 30)
    {
        fprintf(stderr, "The PSNR is less than standard 30 dB, It is Recommended to use a larger Image \n");
    }

    fprintf(stderr, "=================================================== \n");

    return new_img;
}

/* *********************************************************
 * Extract the string encoded in the red channel of newimg, by comparing it
 * with oldimg. The two images must have the same size.
 * Returns a new C string, or NULL on error.
 * **********************************************************/
char *decode(const struct PPM *oldimg, const struct PPM *newimg)
{
    // Checking if the old image is empty
    if (oldimg == NULL)
    {
        exception("The old image is empty");
    }

    // Checking if the new image is empty
    if (newimg == NULL)
    {
        exception("The new image is empty");
    }

    // Checking if the images are the same size
    if (oldimg->height != newimg->height || oldimg->width != newimg->width)
    {
        exception("The old image and the new image are not the same size");
    }
    
    // Checking if the images are the same max
    if (oldimg->max != newimg->max)
    {
        exception("The old image and the new image are not of the same max colour value");
    }

    // Allocating Dynamic memory for the message
    char *message = malloc(2);
    if (message == NULL)
    {
        exception("Memory Allocation Failed");
    }
    strcpy(message, "");

    // Calculating the total number of pixels
    int Total_Pixels = oldimg->height * oldimg->width;

    // Find the Intial position of the message
    int intial_pos = 0;
    for (int i = 0; i < countBits(Total_Pixels); i++)
    {
        int bit = newimg->pixels[i].red & 1; // Extracting the LSB
        intial_pos = (intial_pos << 1) | bit; // Adding the bit to the intial position
    }

    // Decalaration of variables helping in the extraction of the message
    char c = 0;
    int count = 0;

    // Extracting the message
    for (int i = 0; i < Total_Pixels - countBits(intial_pos)-1; i++)
    {

        // Calculating the position of the bit
        int position = (intial_pos + i) % Total_Pixels; // Wrap Arround
        if (position < intial_pos)
        {
            position += countBits(Total_Pixels); // Wrap Around the Reserved Pixels
        }

        // Checking if the bit is different from the old image ie comparing
        if (newimg->pixels[position].red != oldimg->pixels[position].red)
        {
            // As per the algorithm if difference is greater than 2 or -2 then its not the original image of the encoded image file
            if(newimg->pixels[position].red - oldimg->pixels[position].red > 2 || newimg->pixels[position].red - oldimg->pixels[position].red < -2)
            {
                exception("The image Has been Tempered or Images are not the same");
            }

            c = (c << 1) | (newimg->pixels[position].red & 1);
            count++;

            // After 8 bits, add the character to the message
            if (count % 8 == 0)
            {
                message = realloc(message, strlen(message) + 2);
                if (message == NULL)
                {
                    exception("Memory Allocation Failed");
                }
                strcat(message, &c);
                c = 0;
            }
            
        }
    }

    return message;
}

/* *********************************************************
 * Main program
 * **********************************************************/

int main(int argc, char *argv[])
{
    /* Initialise the random number generator, using the time as the seed */
    srand(time(NULL));

    /* Parse command-line arguments */
    if (argc == 3 && strcmp(argv[1], "t") == 0)
    {
        /* Mode "t" - test PPM reading and writing */

        struct PPM *img = readPPM(argv[2]);
        if (img == NULL)
        {
            return 1;
        }

        // Show the PPM image
        showPPM(img);

        // Free up the memory
        garbage_collector(img);
    }
    else if (argc == 3 && strcmp(argv[1], "e") == 0)
    {
        /* Mode "e" - encode PPM */

        struct PPM *oldimg = readPPM(argv[2]);
        if (oldimg == NULL)
        {
            return 1;
        }

        // Display Max characters that can be encoded
        int AvailablePixels = oldimg->height * oldimg->width - countBits(oldimg->height * oldimg->width);
        fprintf(stderr, "Max Characters that can be encoded: %d \n", AvailablePixels / 8);

        /* read a message from the user, and read it into a string */
        char *message = malloc(sizeof(char) * 1);
        if (message == NULL)
        {
            exception("Error in allocating memory for the message");
        }
        strcpy(message, "");  //Intialize the message to be empty

        fprintf(stderr, "Enter the message: ");
        //Read the characters iteratively from console 
        char c = getchar();
        while (c != '\n')
        {
            message = realloc(message, sizeof(char) * (strlen(message) + 2));
            if (message == NULL)
            {
                exception("Error in allocating memory for the message");
            }
            strncat(message, &c, 1);
            c = getchar();
            if(isascii(c)==0){
                exception("The message contains non-ascii characters");
            }
        }

        // Checking if the message is empty
        if (strlen(message) == 0)
        {
            exception("The message is empty");
        }

        // calculating the load factor
        float load_factor = (float)(strlen(message) * 8 + countBits(oldimg->width * oldimg->height)) / (oldimg->width * oldimg->height);
        fprintf(stderr, "\nLoad factor: %f \n", load_factor);

        // Checking if the message is too long compared to length of the binary of the message
        if ((strlen(message) * 8 + countBits(oldimg->width * oldimg->height)) > oldimg->width * oldimg->height)
        {
            exception("The message is too long to be stored in the image\nLoad Factor is greater than 1");
        }

        struct PPM *newimg;
        /* encode the text into the image with encode, and assign to newimg */
        newimg = encode(message, oldimg);
        /* write the image to stdout with showPPM */
        showPPM(newimg);

        // Free up the memory
        garbage_collector(oldimg);

        free(newimg->pixels);
        free(newimg);

        // Free up the memory for the message
        free(message);
    }
    else if (argc == 4 && strcmp(argv[1], "d") == 0)
    {
        /* Mode "d" - decode PPM */

        struct PPM *oldimg;
        /* get original file filename from argv, load it with
           readPPM, then assign to oldimg */
        oldimg = readPPM(argv[2]);
        if (oldimg == NULL)
        {
            return 1;
        }

        struct PPM *newimg;
        /* get encoded file filename from argv, load it with
           readPPM, then assign to newimg */
        newimg = readPPM(argv[3]);
        if (newimg == NULL)
        {
            return 1;
        }

        char *message;
        /* decode the encodedPPM with the comparisonPPM and assign to message */

        message = decode(oldimg, newimg);

        /* print the decoded message to stdout */
        fprintf(stderr, "Decoded Message: %s \n", message);

        // Free up the memory
        garbage_collector(oldimg);
        garbage_collector(newimg);
        free(message);
    }
    else
    {
        fprintf(stderr, "Unrecognised or incomplete command line.\n");
        return 1;
    }

    return 0;
}

/************************************
 * Function to print the exception
 *************************************/
void exception(char *messaage)
{
    fprintf(stderr, "========================== Error Encountered ========================== \n");
    fprintf(stderr, "%s\n", messaage);
    fprintf(stderr, "======================================================================= \n");
    exit(1);
}

/*********************************************************
 * Function that retrieves the comments from the ppm file
 **********************************************************/
void comments_retriever(FILE *f, struct Node *head)
{

    char ch;
    struct Node *temp = head;
    int node_count = 0;

    // Allocate memory for the comments
    char *comments = malloc(2);
    if (comments == NULL)
    {
        exception("Memory Allocation Error");
    }

    // Read the first character
    ch = getc(f);
    if (ch != '#')
    {
        ch = getc(f);
    }

    // Check if the first character is a comment
    if (ch == '#')
    {
        node_count++;
        strcpy(comments, "#"); // Initialize the comments with #
    }

    // Read till all the comments are read
    while (ch == '#')
    {
        // Read till the end of the line
        while (ch != '\n')
        {
            ch = getc(f);
            comments = realloc(comments, strlen(comments) + 1 + 1);
            if (comments == NULL)
                exception("Memory Allocation Error");
            strncat(comments, &ch, 1);
        };

        // Store the comments in the linked list
        temp->comment = comments;

        // Reset variables
        comments = NULL;
        temp->next = NULL;

        // Read the next character
        ch = getc(f);
        if (ch == '#')
        {
            // Allocate memory for the next node
            temp->next = malloc(sizeof(struct Node));
            if (temp->next == NULL)
                exception("Memory Allocation Error");
            node_count++;

            // Move to the next node
            temp = temp->next;

            // reAllocate memory for the next comments
            comments = malloc(2);
            if (comments == NULL)
                exception("Memory Allocation Error");

            strcpy(comments, "#");
        }
    }

    //Unintialize the temperory variable
    temp = NULL;

    fseek(f, -1, SEEK_CUR);
    fprintf(stderr, "Node Memory Allocation: %ld Bytes \n", sizeof(struct Node) * node_count);

    // Free memory for comments
    free(comments);
}
/*********************************************************
 * Function that removes all the dynamic memory allocated
 **********************************************************/

void garbage_collector(_PPM_ *img)
{


    // Free the memory of pixel array
    if (img->pixels != NULL)
        free(img->pixels);

    // free memory for comments Node and its comment
    struct Node *temp = img->comments;
    while (temp != NULL)
    {
        if (temp->comment != NULL)
            free(temp->comment);
        struct Node *temp2 = temp;
        temp = temp->next;
        if (temp2 != NULL)
            free(temp2);
    }

    // Free the memory of the image
    if (img == NULL)
    {
        return;
    }
    free(img);
}

/*********************************************************
 * Function that calculates the no.of bits in a number
 *********************************************************/

unsigned int countBits(unsigned int num)
{
    return log2(num) + 1;
}

/*********************************************************
 * Function that encrypts the bit into the pixel
 *********************************************************/

void encryptBit(struct Pixel *pixel, int bit)
{
    if ((pixel->red & 1) == bit)
        pixel->red = pixel->red ^ 2;
    
    pixel->red = (pixel->red & ~1) | bit;
}

/***************************
 * References:
 * https://www.geeksforgeeks.org/count-total-bits-number/
 * https://core.ac.uk/reader/81148270 (Analysis Concepts)
 *
 */